

function create()
	time = 0

	newColor = true

	local h = math.random()
	local s = math.random()
	local v = 1
	local r, g, b = hsvToRgb(h, s, v, 255)

	nowL = {}
	nextL = {}
	fgleds = {}
    for x=0,21 do
		nowL[x] = {}
		nextL[x] = {}
		fgleds[x] = {}
        for y=0,6 do
		    nowL[x][y] = { r = r, g = g, b = b, a = 255 }
			nextL[x][y] = { r = r, g = g, b = b, a = 255 }
			fgleds[x][y] = { r = 0, g = 0, b = 0, a = 0 }

			setLed(x, y, nowL[x][y].r, nowL[x][y].g, nowL[x][y].b)
		end
	end

	setUPS(15)

	tTime = 5
	kTime = 60

	circles = {}
end

function update(dt)
	time = time + dt

	if time % kTime <= tTime then
		local line = 6-math.ceil((time % kTime) * 9)
		for x=0,21 do
			for y=6,0,-1 do
				if y < line then break end
				nowL[x][y].r = lerp(nowL[x][y].r, nextL[x][y].r, 0.3)
				nowL[x][y].g = lerp(nowL[x][y].g, nextL[x][y].g, 0.3)
				nowL[x][y].b = lerp(nowL[x][y].b, nextL[x][y].b, 0.3)
			end
		end
		newColor = true

	elseif newColor then
		local h = math.random()
		local s = 1
		local v = 1

		local r, g, b = hsvToRgb(h, s, v, 255)

		for x=0,21 do
			for y=0,6 do
				nextL[x][y].r, nextL[x][y].g, nextL[x][y].b = r, g, b
			end
		end

		newColor = false
	end


	for k,v in pairs(circles) do
		local maxr = 4

		local a = 1 - (v.rad / maxr)

		drawCircle(v.x, v.y, v.rad, v.r, v.g, v.b, v.a * a)

		if v.rad > 1 then
			drawCircle(v.x, v.y, v.rad - 1, v.r, v.g, v.b, v.a * a)
		end

		v.rad = v.rad + 10 * dt

		if v.rad > maxr  then
			table.remove(circles, k)
		end
	end

	-- Draw everything
	for x=0,21 do
		for y=0,6 do
			local r1, g1, b1 = nowL[x][y].r, nowL[x][y].g, nowL[x][y].b
			local r2, g2, b2 = fgleds[x][y].r, fgleds[x][y].g, fgleds[x][y].b

			local t = fgleds[x][y].a / 255
			local r, g, b = lerp(r1, r2, t), lerp(g1, g2, t), lerp(b1, b2, t)

			setLed(x, y, r, g, b)


			fgleds[x][y].r, fgleds[x][y].g, fgleds[x][y].b, fgleds[x][y].a = 0, 0, 0, 0
		end
	end

end

function lerp(a, b, t)
	return a + t * (b - a)
end

function keyDown(vkcode, x, y, key)
	table.insert(circles, { x = x, y = y, rad = 0, r = 0, g = 0, b = 0, a = 255 })
end

function keyUp(x, y, key)
end

function drawCircle(x, y, radius, r, g, b, a)
    for i = 1, 360 do
        local angle = i * math.pi / 180
        local ptx, pty = x + radius * math.cos( angle ), y + radius * math.sin( angle )
        ptx = math.floor(ptx + 0.5)
        pty = math.floor(pty + 0.5)

        if ptx >= 0 and pty >= 0 and ptx <= 21 and pty <= 6 then
            fgleds[ptx][pty].r = r
			fgleds[ptx][pty].g = g
			fgleds[ptx][pty].b = b
			fgleds[ptx][pty].a = a
        end
    end
end


function hsvToRgb(h, s, v, a)
  local r, g, b

  local i = math.floor(h * 6);
  local f = h * 6 - i;
  local p = v * (1 - s);
  local q = v * (1 - f * s);
  local t = v * (1 - (1 - f) * s);

  i = i % 6

  if i == 0 then r, g, b = v, t, p
  elseif i == 1 then r, g, b = q, v, p
  elseif i == 2 then r, g, b = p, v, t
  elseif i == 3 then r, g, b = p, q, v
  elseif i == 4 then r, g, b = t, p, v
  elseif i == 5 then r, g, b = v, p, q
  end

  return r * 255, g * 255, b * 255, a * 255
end
