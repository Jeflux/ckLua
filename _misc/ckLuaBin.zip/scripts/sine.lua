

function create()
	time = 0
	sinestep = 0

	circles = {}


	bgleds = {}
	fgleds = {}
    for x=0,21 do
		bgleds[x] = {}
		fgleds[x] = {}
        for y=0,6 do
			local r = 0
			local g = 0
			local b = 0

		    bgleds[x][y] = { r = r, g = g, b = b, a = 255 }
			fgleds[x][y] = { r = 0, g = 0, b = 0, a = 255 }
		end
	end

end

function update(dt)
	time = time + dt

	for x=0,21 do
        for y=0,6 do
			repeat
				fgleds[x][y].r, fgleds[x][y].g, fgleds[x][y].b, fgleds[x][y].a = 0, 0, 0, 0

				if x <= 0 or x >= 14 then break end

				local base = 4 + math.sin(x + math.pi + sinestep)

				if y == math.floor(base + 0.5) then
					fgleds[x][y].r = 80
					fgleds[x][y].g = 70
					fgleds[x][y].b = 200
					fgleds[x][y].a = 255

				end

			until true
		end
	end

	for x=18,21 do
        for y=2,6 do
			repeat

				fgleds[x][y].r = 80
				fgleds[x][y].g = 70
				fgleds[x][y].b = 200

				fgleds[x][y].a = (1 + math.sin((y / 21 * math.pi + time) * 4)) / 2 * 255

			until true
		end
	end



	for k,v in pairs(circles) do
		local maxr = 4

		local a = 1 - (v.rad / maxr)

		drawCircle(v.x, v.y, v.rad, v.r, v.g, v.b, v.a * a)

		if v.rad > 1 then
			drawCircle(v.x, v.y, v.rad - 1, v.r, v.g, v.b, v.a * a)
		end

		v.rad = v.rad + 20 * dt

		if v.rad > maxr  then
			table.remove(circles, k)
		end
	end


	for x=0,21 do
        for y=0,6 do
			local r1 = bgleds[x][y].r
			local g1 = bgleds[x][y].g
			local b1 = bgleds[x][y].b

			local r2 = fgleds[x][y].r
			local g2 = fgleds[x][y].g
			local b2 = fgleds[x][y].b
			local a = fgleds[x][y].a / 255

			local r = lerp(r1, r2, a)
			local g = lerp(g1, g2, a)
			local b = lerp(b1, b2, a)

			setLed(x, y, r, g, b)
		end
	end
end

function lerp(a, b, t)
	return a + t * (b - a)
end


function drawCircle(x, y, radius, r, g, b, a)
    for i = 1, 360 do
        local angle = i * math.pi / 180
        local ptx, pty = x + radius * math.cos( angle ), y + radius * math.sin( angle )
        ptx = math.floor(ptx + 0.5)
        pty = math.floor(pty + 0.5)

        if ptx >= 0 and pty >= 0 and ptx <= 21 and pty <= 6 then
            fgleds[ptx][pty].r = r
			fgleds[ptx][pty].g = g
			fgleds[ptx][pty].b = b
			fgleds[ptx][pty].a = a
        end
    end
end


function keyDown(vkcode, x, y, key)
	sinestep = sinestep - 1
	table.insert(circles, { x = x, y = y, rad = 0, r = 255, g = 255, b = 255, a = 255 })
end

function keyUp(x, y, key)
end
